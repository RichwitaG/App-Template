export default function FeaturesPage() {
  return (
    <div>
      <h1>Features</h1>
    </div>
  )
}
