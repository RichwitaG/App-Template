export default function PricingPage() {
  return (
    <div>
      <h1>Pricing</h1>
    </div>
  )
}
