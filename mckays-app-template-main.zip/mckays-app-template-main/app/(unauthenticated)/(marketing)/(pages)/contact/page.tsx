export default function ContactPage() {
  return (
    <div>
      <h1>Contact</h1>
    </div>
  )
}
